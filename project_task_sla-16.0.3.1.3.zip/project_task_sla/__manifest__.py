# -*- coding: utf-8 -*-

# Part of Probuse Consulting Service Pvt Ltd. See LICENSE file for full copyright and licensing details.

{
    'name' : 'Service Level Agreement for Task (SLA)',
    'version': '3.1.3',
    'author': 'Probuse Consulting Service Pvt. Ltd.',
    'category' : 'Services/Project',
    'website': 'https://www.probuse.com',
    'summary' : 'Project Task with Service Level Agreement (SLA)',
    'price' : 99.0,
    'images': ['static/description/image.jpg'],
    'live_test_url': 'https://probuseappdemo.com/probuse_apps/project_task_sla/379',#'https://youtu.be/0wkfULg_l6E',
    'currency': 'EUR',
    'license': 'Other proprietary',
    'description': '''
        Project Task Service Level Agreement (SLA)
        Customer SLA for Project Tasks in Odoo
        Tasks SLA and Deadline and SLA Time Logs
        Allow your project team to manage SLA Levels under configuration.
        Allow your project team to create and manage service level agreements under configuration.
        Allow your team to create and manage SLA categories.
        Allow you to create project teams (check dependent apps to get more details about it).
        Systems create time logs when users move tasks from one stage to another stage based on service level agreements setup.
        Allow your team to set SLA level on the customer form which will be used to compute the deadline while creating tasks for that customer based on service level agreements with your customer.
        Allow your user to set priority of tasks on task form.
        Requested date will be set automatically as the current date but you still can change it and based on that requested date, the system will compute the deadline using SLA level for that customer.
        SLA time logs will give you details by stages about time the user has spent for that stage based on service level agreements setup and it also show delays if any on working for that stage for that task.
        This app will help you to manage deadlines of tasks based on SLA with your customer and also make SLA logs based on stages of tasks of the project.
  ''',
    'depends':[
        'project',
        'project_team_odoo',
    ],
    'data' : [
        'security/ir.model.access.csv',
        'views/task_level_config_view.xml',
        'views/task_sla_view.xml',
        'views/task_stage_history_view.xml',
        'views/res_partner_view.xml',
        'views/resource_calendar_view.xml',
        'views/project_task_view.xml',
        'views/task_sale_category_view.xml',
    ],
    'installable':True,
    'auto_install':False
}

