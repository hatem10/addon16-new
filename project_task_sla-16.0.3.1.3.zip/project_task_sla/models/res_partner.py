# -*- coding: utf-8 -*-

from odoo import models, fields, api


class ResPartner(models.Model):
    _inherit = 'res.partner'
    
    custom_level_config_id_task = fields.Many2one(
        'task.sla.level.config',
        string="Task SLA Level Config",
    )
