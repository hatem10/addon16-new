# -*- coding: utf-8 -*-

from odoo import models, fields


class TaskSLACategory(models.Model):
    _name = 'task.sla.category.custom'
    _description = 'Task SLA Category'

    name = fields.Char(
        'Name',
        required=True,
    )