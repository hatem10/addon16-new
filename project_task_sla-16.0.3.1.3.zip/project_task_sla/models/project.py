# -*- coding: utf-8 -*

from odoo import models, fields, api
from datetime import datetime
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

class Task(models.Model):
    _inherit = "project.task"

    stage_history_ids = fields.One2many(
        'task.sla.stage.history',
        'task_id',
        string="SLA Stage History",
        copy=False,
    )
    custom_level_config_id = fields.Many2one(
        'task.sla.level.config',
        string="SLA Deadline Level",
    )
    custom_category_id = fields.Many2one(
        'task.sla.category.custom',
        string="SLA Category",
    )
    dead_line_date = fields.Datetime(
        string="SLA Deadline",
        copy=False
    )
    request_date = fields.Datetime(
        string='Requested Date',
        default=fields.Datetime.now,
        copy=False,
    )
    custom_priority = fields.Selection(
        [('0', 'Low'),
        ('1', 'Middle'),
        ('2', 'High')],
        string='SLA Priority',
    )
    

    @api.onchange("partner_id")
    def _onchange_partner_id_custom(self):
        for rec in self:
            rec.custom_level_config_id = rec.partner_id.custom_level_config_id_task or rec.partner_id.commercial_partner_id.custom_level_config_id_task or False

    @api.model
    def _get_stage_start_history(self, stage_id):
        TaskStageHistoryObj = self.env['task.sla.stage.history'].sudo()
        domain = [
            ('task_id', '=', self.id),
            ('dest_stage_id', '=', stage_id)
        ]
        stage_start_line = TaskStageHistoryObj.search(domain)
        return stage_start_line

    @api.model
    def _compute_deadline(self, request_date, sla_level_id, vals):
        #to trigger this you have to change priority, category, SLA field, team on ticket form... 18 Dec 2019 hint....
        request_date = datetime.strptime(str(request_date), "%Y-%m-%d  %H:%M:%S")
        SLAObj = self.env['task.sla.agreements'].sudo()

        if vals.get('project_team_id', False):
            team_id = vals.get('project_team_id', False)
        elif self.project_team_id:
            team_id = self.project_team_id.id
        else:
            team_id = self.env['project.project.team'].sudo().search([],limit=1).id
            # team_id = self.env['support.team'].sudo()._get_default_team_id(user_id=self.env.uid).id

        SLA_record = SLAObj.search([('task_team_id', '=', team_id)],limit=1)
        calendar_id = SLA_record.calendar_id
#        company = self.env.user.company_id
        if vals.get('company_id'):
            company = self.env['res.company'].browse(vals.get('company_id'))
        elif self.company_id:
            company = self.company_id
        else:
            company = self.env.company_id
        if vals.get('user_id', False):
            task_user = vals.get('user_id', False)
        # elif self.user_id:
        elif self.user_ids:
            # task_user = self.user_id.id
            task_user = self.user_ids.ids
        else:
            task_user = self._uid
        resource_domain = [
            ('calendar_id', '=', calendar_id.id),
            ('user_id', '=', task_user),
            ('company_id', '=', company.id),
            ('resource_type', '=', 'user'),
            ('active', '=', True),
        ]
        resource_id = self.env['resource.resource'].sudo().search(resource_domain,limit=1)
#        resource_id = resource_id and resource_id.id or False
        resource_id = resource_id or False

        dead_line_date = False
        if sla_level_id and resource_id:
            if vals.get('custom_priority', False):
                priority = vals.get('custom_priority', False)
            else:
                priority = self.custom_priority
            if vals.get('custom_category_id', False):
                category = vals.get('custom_category_id', False)
            else:
                category = self.custom_category_id.id
            line = sla_level_id.line_ids.filtered(lambda l: l.custom_category_id.id == category and l.priority == priority)
            if line:
                interval = line.period_number
                if line.period_type == 'hours':
                    next_working_days = calendar_id.plan_hours(interval * 1.0,
                                                               day_dt=request_date,
                                                               compute_leaves=True,
                                                               resource=resource_id)
                    if next_working_days:
                        dead_line_date = next_working_days# + timedelta(days=1)
#                     if next_working_days and next_working_days[0][0]:
#                         dead_line_date = next_working_days[0][0]
                elif line.period_type == 'days':
                    #                     next_working_days = calendar_id._get_next_work_day(day_date=request_date)\
#                    next_working_days = calendar_id.plan_days(interval * 1.0, odoo13
#                                                               day_dt=request_date,
#                                                               compute_leaves=True,)
##                                                               resource=resource_id) 

                    next_working_days = calendar_id.plan_hours(interval * calendar_id.hours_per_day_probc,
                                                               day_dt=request_date,
                                                               compute_leaves=True,
                                                               resource=resource_id)
                    if next_working_days:
                        dead_line_date = next_working_days# + timedelta(days=1)
        
                elif line.period_type == 'weeks':
#                    interval = line.period_number * 7 odoo13
#                     week_request_date = request_date + relativedelta(days=interval)
#                     next_working_days = calendar_id._get_next_work_day(day_date=week_request_date)
#                     if next_working_days:
#                         dead_line_date = next_working_days

                #                    next_working_days = calendar_id.plan_days(interval * 1.0, odoo13
#                                                               day_dt=request_date,
#                                                               compute_leaves=True,)
##                                                               resource=resource_id)

                    next_working_days = calendar_id.plan_hours(interval * calendar_id.hours_per_week_probc,
                                                               day_dt=request_date,
                                                               compute_leaves=True,
                                                               resource=resource_id)
                    if next_working_days:
                        dead_line_date = next_working_days# + timedelta(days=1)

        return dead_line_date

    @api.model
    def create(self, vals):
        task = super(Task, self).create(vals)

        TicketStageHistoryObj = self.env['task.sla.stage.history']
        SLAObj = self.env['task.sla.agreements'].sudo()

        if task.stage_id:
            team_id = task.project_team_id
            if not team_id:
                # team_id = self.env['support.team'].sudo()._get_default_team_id(user_id=self.env.uid)
                team_id = self.env['project.project.team'].sudo().search([],limit=1)
            source_stage_id = task.stage_id.id
            # if task.user_id:
            if task.user_ids:
                # task_user = task.user_id.id
                task_user = task.user_ids.id
            else:
                task_user = self._uid
            history_vals = {
                    'stage_id': source_stage_id,
                    'dest_stage_id': source_stage_id,
                    'start_time': fields.Datetime.now(),
                    'user_id': task_user,
                    'team_id': team_id.id,
            }
            SLA_record = SLAObj.search([('task_team_id', '=', team_id.id)], limit=1)
            if SLA_record:
                sla_lines = SLA_record.sla_line_ids
#                     stage_validate_line = sla_lines.filtered(lambda l: l.source_stage_id.id == source_stage_id and l.destination_stage_id.id == dest_stage_id)
                stage_validate_line = sla_lines.filtered(lambda l: l.source_stage_id.id == source_stage_id)
                if stage_validate_line:
                    history_vals.update({
                        'estimate_time': stage_validate_line.service_time,
                        'calendar_id': stage_validate_line.sla_id.calendar_id.id
                    })
            task.write({'stage_history_ids': [(0, 0, history_vals)]})

        # compute deadline
        if task.request_date and task.custom_level_config_id:
            dead_line_date = task._compute_deadline(task.request_date, task.custom_level_config_id, vals)
            task.date_deadline = dead_line_date
            task.dead_line_date = dead_line_date
        return task

    
    def write(self, vals):
        SupportTeamObj = self.env['project.project.team'].sudo()
        SLAObj = self.env['task.sla.agreements'].sudo()
        TaskStageHistoryObj = self.env['task.sla.stage.history']

        for task in self:
            # compute new deadline if it is not set in previous time
#             if not ticket.dead_line_date and not vals.get('dead_line_date', False):
                if vals.get('custom_level_config_id', False) or vals.get('custom_priority', False) or vals.get('custom_category_id', False) or vals.get('team_id', False) or vals.get('user_id', False):
                    if vals.get('custom_level_config_id', False):
                        sla_level_id = self.env['task.sla.level.config'].sudo().browse(vals['custom_level_config_id'])
                    else:
                        sla_level_id = task.custom_level_config_id
#                     sla_level_id = self.env['helpdesk.level.config'].sudo().browse(level_config_id)
                    custom_request_sate = vals.get('request_date') or task.request_date
#                    if ticket.request_date and sla_level_id:
#                        dead_line_date = ticket._compute_deadline(ticket.request_date, sla_level_id, vals)
                    if custom_request_sate and sla_level_id:
                        dead_line_date = task._compute_deadline(custom_request_sate, sla_level_id, vals)
                        vals.update({'date_deadline': dead_line_date,'dead_line_date': dead_line_date})

        if vals.get('stage_id', False):
            for task in self:
                team_id = task.project_team_id
                if vals.get('team_id', False):
                    team_id = SupportTeamObj.browse(int(vals['team_id']))
                source_stage_id = task.stage_id.id
                dest_stage_id = vals['stage_id']

                stage_start_line = task._get_stage_start_history(source_stage_id)
                if stage_start_line:
                    stage_start_line.write({'end_time' :fields.Datetime.now()})
                # if task.user_id:
                if task.user_ids:
                    # task_user = task.user_id.id
                    task_user = task.user_ids.id
                else:
                    task_user = self._uid
                history_vals = {
                    'task_id': task.id,
                    'stage_id': source_stage_id,
                    'dest_stage_id': dest_stage_id,
                    'start_time': fields.Datetime.now(),
                    'user_id': task_user,
                    'team_id': team_id.id,
                }
                SLA_record = SLAObj.search([('task_team_id', '=', team_id.id)], limit=1)
                if SLA_record:
                    sla_lines = SLA_record.sla_line_ids
                    stage_validate_line = sla_lines.filtered(lambda l: l.source_stage_id.id == dest_stage_id)
                    if stage_validate_line:
                        history_vals.update({
                            'estimate_time': stage_validate_line.service_time,
                            'calendar_id': stage_validate_line.sla_id.calendar_id.id
                        })
                history_line = TaskStageHistoryObj.create(history_vals)
        return super(Task, self).write(vals)