# -*- coding: utf-8 -*-

from odoo import models, fields


class TaskSLAAgreements(models.Model):
    _name = 'task.sla.agreements'
    _description = 'Service Level Agreement'

    name = fields.Char(
        'Name',
        required=True,
    )
    task_team_id = fields.Many2one(
        'project.project.team',
        'Project Team',
        required=True,
    )
    sla_line_ids = fields.One2many(
        'task.sla.line',
        'sla_id',
        'SLA Lines',
        copy=True,
    )
    user_id = fields.Many2one(
        'res.users',
        string='Created by',
        default=lambda self: self.env.user,
        readonly=False,
    )
    company_id = fields.Many2one(
        'res.company', 
        default=lambda self: self.env.user.company_id, 
        string='Company',
        readonly=True,
    )
    calendar_id = fields.Many2one(
        'resource.calendar',
        'Resource Calendar',
        required=True,
    )
    notes = fields.Text(
        'Add comment'
    )
    active = fields.Boolean(
        default=True, 
        copy=True,
    )


class TaskSlaLine(models.Model):
    _name = 'task.sla.line'
    _description = 'Service Level Agreement Lines'
    
    source_stage_id = fields.Many2one(
        'project.task.type',
        string="Stage From",
        required=True,
    )
    destination_stage_id = fields.Many2one(
        'project.task.type',
        string="Stage To",
        required=False,
    )
    service_time = fields.Float(
        'Time',
        copy=False,
        required=True
    )
    sla_id = fields.Many2one(
        'task.sla.agreements',
        'Service Level Agreement'
    )
