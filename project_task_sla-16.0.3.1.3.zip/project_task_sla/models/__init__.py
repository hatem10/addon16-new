# -*- coding: utf-8 -*-

from . import task_level_config
from . import task_sla
from . import task_stage_history
from . import res_partner
from . import resource_calendar
from . import project
from . import task_sla_category