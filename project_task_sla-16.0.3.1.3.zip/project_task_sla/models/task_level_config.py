# -*- coding: utf-8 -*-

from odoo import models, fields


class TaskSLALevelConfig(models.Model):
    _name = 'task.sla.level.config'
    _description = 'Task SLA Level Configuration'

    name = fields.Char(
        string="Name",
        required=True,
    )
    line_ids = fields.One2many(
        'task.sla.level.config.line',
        'custom_level_config_id',
        string="SLA Level Configurations",
        copy=True
    )
    active = fields.Boolean(
        default=True, 
        copy=True,
    )

class TaskLevelConfigLines(models.Model):
    _name = 'task.sla.level.config.line'
    _description = 'Task SLA Level Configuration Line'

    custom_level_config_id = fields.Many2one(
        'task.sla.level.config',
        string="Task Level Configuration",
    )
    # category = fields.Selection(
    #     [('technical', 'Technical'),
    #     ('functional', 'Functional'),
    #     ('support', 'Support')],
    #     string='Category',
    #     required=True,
    # )
    custom_category_id = fields.Many2one(
        'task.sla.category.custom',
        string="Category",
        required=True
    )
    priority = fields.Selection(
        [('0', 'Low'),
        ('1', 'Middle'),
        ('2', 'High')],
        string='Priority',
        required=True,
    )
    period_number = fields.Integer(
        string="Gap",
        required=True,
    )
    period_type = fields.Selection(
        [('hours', 'Hours'),
        ('days', 'Days'),
        ('weeks', 'Weeks')],
        string="Period Type",
        required=True,
    )
