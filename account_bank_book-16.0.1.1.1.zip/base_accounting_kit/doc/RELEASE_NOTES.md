## Module <base_accounting_kit>

#### 14.10.2022

#### Version 16.0.1.0.0

#### ADD

- Initial commit for Odoo 16 accounting

#### 08.03.2023

#### Version 16.0.2.0.0

#### IMP

- Added Anglo Saxon Accounting Feature

#### 09.06.2023

#### Version 16.0.2.0.3

#### UPDT

- Bug Fix

#### 15.06.2023

#### Version 16.0.2.0.4

#### UPDT

- Bug Fix

#### 11.07.2023

#### Version 16.0.2.0.5

#### UPDT

- Cash journal Bug Fix

#### 17.08.2023

#### Version 16.0.2.0.7

#### UPDT

- Asset type Bug Fix

### 02.11.2023

### Version 16.0.2.0.10

### UPDT

- Payment Register Bank and Cheque References Bug Fix

### 08.11.2023

### Version 16.0.2.0.11

### UPDT

- Payment Receipt  Bank and Cheque reference Report Bug Fix

### 30.11.2023

### Version 16.0.2.0.12

### UPDT

- Automatic Asset Creation Bug Fix
