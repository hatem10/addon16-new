/** @odoo-module */

import { registry } from "@web/core/registry";
import { download } from "@web/core/network/download";
import framework from 'web.framework';
import session from 'web.session';

// Adding excel to the report handlers and redirect to url /bank_xlsx_reports
registry.category("ir.actions.report handlers").add("bank_book_xlsx", async (action) => {
    if (action.report_type === 'bank_book_xlsx') {
        framework.blockUI();
        var def = $.Deferred();
        session.get_file({
            url: '/bank_xlsx_reports',
            data: action.data,
            success: def.resolve.bind(def),
            error: (error) => this.call('crash_manager', 'rpc_error', error),
            complete: framework.unblockUI,
        });
        return def;
    }
});
