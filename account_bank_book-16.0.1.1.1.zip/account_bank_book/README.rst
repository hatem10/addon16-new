.. image:: https://img.shields.io/badge/licence-OPL--1-blue.svg
    :target: http://www.gnu.org/licenses/opl-1.0-standalone.html
    :alt: License: OPL-1
Bank Book Reports
====================
Generate Bank Book Report in Both PDF and XLSX fromat

Installation
============
	- www.odoo.com/documentation/14.0/setup/install.html
	- Install our custom addon

Configuration
=============

    * You need to install base_accounting_kit for using this module.

License
-------
Odoo Proprietary License v1.0 (OPL-1)
(https://www.odoo.com/documentation/16.0/legal/licenses.html)

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com
This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com

Credits
=======
    Developer: Mashood K.U @ cybrosys, Contact: odoo@cybrosys.com
               V13 Sreejith S @ cybrosys, Contact: odoo@cybrosys.com
               V14 Varsha S @ cybrosys, Contact: odoo@cybrosys.com
               V16 Sahla Sherin @ cybrosys, Contact: odoo@cybrosys.com
