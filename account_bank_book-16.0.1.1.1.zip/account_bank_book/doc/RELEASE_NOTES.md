## Module <account_bank_book>

#### 17.11.2021
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Bank Book Report

#### 21.11.2023
#### Version 16.0.1.1.1
##### BUG FIX
- Fixed the error in Excel report when no account is given
