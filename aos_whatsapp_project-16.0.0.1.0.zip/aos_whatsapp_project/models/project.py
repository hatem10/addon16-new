# See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, sql_db, _
from odoo.tools.mimetypes import guess_mimetype
import requests
import json
import base64
from datetime import datetime
import time
import html2text
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


class ProjectTask(models.Model):
    _inherit = 'project.task'
    
    def get_link(self):
        for task in self:
            base_url = task.get_base_url()
            share_url = task._get_share_url(redirect=True, signup_partner=True)
            url = base_url + share_url
            return url

    def _get_whatsapp_server(self):
        WhatsappServer = self.env['ir.whatsapp_server']
        whatsapp_ids = WhatsappServer.search([('status','=','authenticated')], order='sequence asc', limit=1)
        if whatsapp_ids:
            return whatsapp_ids
        return False
    
    def send_whatsapp_automatic(self):
        for task in self:
            new_cr = sql_db.db_connect(self.env.cr.dbname).cursor()
            MailMessage = self.env['mail.message']
            WhatsappComposeMessage = self.env['whatsapp.compose.message']
            template_id = self.env.ref('aos_whatsapp_project.project_tasks_update_status', raise_if_not_found=False)
            if self._get_whatsapp_server() and self._get_whatsapp_server().status == 'authenticated':
                KlikApi = self._get_whatsapp_server().klikapi()
                KlikApi.auth()
                template = template_id.generate_email(task.id, ['body_html', 'subject'])
                body = template.get('body_html')
                subject = template.get('subject')
                try:
                    body = body.replace('_NAME_', task.name).replace('_STAGE_', task.stage_id.name).replace('\xa0', ' ').replace('"', "*").replace("'", "*")
                except:
                    _logger.warning('Failed to send Message to WhatsApp number %s', task.partner_id.whatsapp)         
                #print ('==body==',body,partner.name,task.name,task.stage_id.name)
                attachment_ids = []
                chatIDs = []
                message_data = {}
                send_message = {}
                #status = 'error'
                status = 'pending'
                partners = task.message_partner_ids#self.env['res.partner']
                if task.partner_id:
                    partners += task.partner_id
                    # if task.partner_id.child_ids:
                    #     #ADDED CHILD FROM PARTNER
                    #     for partner in task.partner_id.child_ids:
                    #         partners += partner  
                print ('===XXXX===',partners) 
                for partner in partners:
                    if partner.whatsapp:
                        #body = body.replace('_PARTNER_', partner.name)
                        # print ('#SEND MESSAGE==1',partner.whatsapp)
                        whatsapp = partner._formatting_mobile_number()
                        # print ('#SEND MESSAGE==2',whatsapp)
                        if len(whatsapp) >= 5:
                            #body = body.replace('_PARTNER_', partner.name)
                            #print ('=body==',body)
                            message_data = {
                                'method': 'sendMessage',
                                'phone': whatsapp,
                                'body': html2text.html2text(body.replace('_PARTNER_', partner.name)),# + task.get_link(),
                                'link': task.get_link(),
                                # 'state': 'pending',   
                            }                        
                        # if partner.chat_id:
                        #     message_data.update({'chatId': partner.chat_id, 'phone': ''})
                        # data_message = json.dumps(message_data)
                        # send_message = KlikApi.post_request(method='sendMessage', data=data_message)
                        # if send_message.get('message')['sent']:
                        #     chatID = send_message.get('chatID')
                        #     status = 'send'
                        #     partner.chat_id = chatID
                        #     chatIDs.append(chatID)
                        #     _logger.warning('Success to send Message to WhatsApp number %s', whatsapp)
                        # else:
                        #     status = 'error'
                        #     _logger.warning('Failed to send Message to WhatsApp number %s', whatsapp)
                            # new_cr.commit()
                            print ('=sendMessage=',partner.name,message_data)
                            AllchatIDs = ';'.join(chatIDs)
                            vals = WhatsappComposeMessage._prepare_mail_message(self.env.user.partner_id.id, AllchatIDs, task and task.id, 'project.task', body.replace('_PARTNER_', partner.name), message_data, subject, partner.ids, attachment_ids, send_message, status)
                            MailMessage.sudo().create(vals)
                            new_cr.commit()
                #time.sleep(3)