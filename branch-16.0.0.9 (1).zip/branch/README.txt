16.0.0.1 ==>fixed issue of branch in stock quant.
16.0.0.2 ==>fixed issue of branch was not coming in 2 or 3 step incoming shipment.
16.0.0.3 ==>fixed issue of branch in stock quant while we have done internal transfer.
16.0.0.4 ==>fixed issue of when select 2 or 3 step incoming shipment at that time show error.
16.0.0.5 ==>Add company domain for branch.
16.0.0.6 ==> Fixed issue of when multi branch boolean field not true still it's show branch dropdown menu in header and also fixed issue of when added any field value in branches at that time that field value can't be remove from suggstion.
16.0.0.7 ==> Fixed issue when product costing method based on FIFO and AVCO then create bill from PO show warining and also when create landed cost at that time trasnfer/picking can't be show and also inventory valuation can't be created fixed it.
16.0.0.8 ==> Fixed issue only select active branch on stock picking & also set when select unactive branch at that time validation raise.
Date:25/09/2023
16.0.0.9 ==> Particular product have a branch name mentioned, it should only be visible to users. Improvments is done.