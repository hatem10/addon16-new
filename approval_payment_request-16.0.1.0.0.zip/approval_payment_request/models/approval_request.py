# -*- coding: utf-8 -*-
from logging import info
import re
from odoo import models, fields, api


class approval_request(models.Model):
    _inherit = 'approval.request'

    request_owner_id = fields.Many2one('res.users', string="Request Owner", check_company=True)
    currency_id = fields.Many2one('res.currency', string="Currency")
    has_currency = fields.Selection(related="category_id.has_currency")
    payment_id = fields.Many2one('account.payment', string="Payment")

    def action_approve(self, approver=None):
        for rec in self:
            res = super().action_approve(approver)
            if rec.category_id.approval_type == 'payment' and not self.payment_id:
                vals = {
                    'payment_type':'outbound',
                    'partner_id': rec.partner_id.id,
                    'amount':rec.amount,
                    'currency_id':rec.currency_id.id,
                    'date':rec.date,
                    'ref': re.sub(re.compile('<.*?>'), '', rec.reason) if rec.reason else '',
                }
                payment = self.env['account.payment'].create(vals)
                self.payment_id = payment.id
                # mail_template = self.env.ref('approval_payment_request.approval_payment_created_email')
                # mail_template.send_mail(payment.id, force_send=True)

            return res
