# -*- coding: utf-8 -*-
from logging import info

from odoo import models, fields, api

CATEGORY_SELECTION = [
    ('required', 'Required'),
    ('optional', 'Optional'),
    ('no', 'None')]

class approval_request(models.Model):
    _inherit = 'approval.category'

    has_currency = fields.Selection(CATEGORY_SELECTION, string="Has Currency", default="no", required=True)
    approval_type = fields.Selection(selection_add=[('payment', 'Create Payment')])


    @api.onchange('approval_type')
    def _onchange_approval_type_payment(self):
        if self.approval_type == 'payment':
            self.has_currency = 'required'
            self.has_amount = 'required'
            self.has_partner = 'required'
            self.has_date = 'required'