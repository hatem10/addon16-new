# -*- coding: utf-8 -*-
{
    'name': 'Payment Approval Request',
    'category': 'Human Resources/Approvals',
    'version': '16.0.1.0.0',
    'sequence': 1,
    'summary': """
        This module adds a new type in the approval App Which is payment request and when approved it creates payment
    """,
    'description': "This module adds a new type in the approval App Which is payment request and when approved it creates payment.",
    'author': 'Emad Al-Futahi',
    'maintainer': 'Emad Al-Futahi',
    'price': '25.0',
    'currency': 'USD',
    'license': 'OPL-1',
    'support':'eakram26@gmail.com',
    'depends': ['base','approvals','account']
    ,
    'data': [
         'views/approval_category_view.xml',
        'views/approval_request_view.xml',
        'security/portal_approval_security.xml',
        # 'data/email_template.xml',
    ],
    'demo': [],
    'images': ['static/description/banner.png'],
    'installable': True,
    'application': False,
    'auto_install': False,
    'live_test_url': 'https://youtu.be/U_CWrTQOPBI',
}