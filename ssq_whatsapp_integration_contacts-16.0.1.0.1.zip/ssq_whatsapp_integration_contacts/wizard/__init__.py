from . import wizard_partner
