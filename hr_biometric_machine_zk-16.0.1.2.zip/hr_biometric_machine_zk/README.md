
# Module for the integration between ZK Biometric Machines and Odoo."
---


Install the library pyzk


pip install -U git+https://github.com/kurenai-ryu/pyzk.git
 
or using pipenv:

pipenv install git+https://gith.com/kurenai-ryu/pyzk#egg=pyzk

or clone and execute:

python setup.py install


Install the module hr_biometric_machine_zk. 

